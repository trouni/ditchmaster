# Make a repository masterless

Simple CLI tool to change a repository's default branch from `master` to `main`.